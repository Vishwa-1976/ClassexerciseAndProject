import React, { useState } from 'react';
import axios from 'axios';
import './LoginPopup.css';
import { assets } from '../../assets/assets';

const LoginPopup = ({ setShowLogin }) => {
    const [currState, setCurrState] = useState("Login");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [name, setName] = useState("");
    const [error, setError] = useState("");

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.get(`http://localhost:3001/users?email=${email}&password=${password}`);
            if (response.data.length > 0) {
                alert("Login successful");
                setShowLogin(false);
            } else {
                setError("Invalid credentials");
            }
        } catch (err) {
            setError("Error during login");
        }
    };

    const handleSignUp = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:3001/users", {
                name,
                email,
                password
            });
            if (response.status === 201) {
                alert("Account created successfully");
                setCurrState("Login");
            }
        } catch (err) {
            setError("Error creating account");
        }
    };

    return (
        <div className='login-popup'>
            <form className="login-popup-container" onSubmit={currState === "Login" ? handleLogin : handleSignUp}>
                <div className="login-popup-title">
                    <h2>{currState}</h2>
                    <img onClick={() => setShowLogin(false)} src={assets.cross_icon} alt="" />
                </div>
                <div className="login-popup-inputs">
                    {currState === "Sign Up" && <input type='text' placeholder='Your name' value={name} onChange={(e) => setName(e.target.value)} required />}
                    <input type='email' placeholder='Your email' value={email} onChange={(e) => setEmail(e.target.value)} required />
                    <input type="password" placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                <button type="submit">{currState === "Sign Up" ? "Create account" : "Login"}</button>

                {error && <p className="error-message">{error}</p>}

                <div className="login-popup-condition">
                    <input type="checkbox" required />
                    <p>By continuing, I agree to the terms of use & privacy policy.</p>
                </div>
                {currState === "Login" ? (
                    <p>Create a new account? <span onClick={() => setCurrState("Sign Up")}>Click here</span></p>
                ) : (
                    <p>Already have an account? <span onClick={() => setCurrState("Login")}>Login here</span></p>
                )}
            </form>
        </div>
    );
};

export default LoginPopup;
